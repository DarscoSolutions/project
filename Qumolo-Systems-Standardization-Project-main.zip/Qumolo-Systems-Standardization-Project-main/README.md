DJ Choi 

Lars Clausen

Courtney Johnson


We were tasked to standardize virtual desktop to Windows 10 Pro. Install Microsoft Outlook Desktop trial version on the sales reps virtual desktop. The sales team will also need both Onedrive and 365 downloaded then synced with their accounts. The software engineers will need Ubuntu Linux Desktop 20.10 installed. They will use Mozilla Thunderbird and would like it connected to the Microsoft 365.

Each desktop should have a backup hard drive that clones nightly at midnight which should include the user profile of the sales rep's computer. The entire OS must be backed up to the backup drive once a week.

Finally, the sales rep needs access to remote into the computer from home. The sales rep is only comfortable using the GUI interface.

